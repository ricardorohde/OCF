<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'O estilo cl&#xe1;ssico que introduz o inovador estilo PHP/MySQL do YaBB e diferenciado por dois anos de desenvolvimento at&#xe9; o nascimento do SMF.<br /><br />Author: <i><a href="mailto:webmaster@yabbse.org">The YaBB SE Team</a></i>.';

?>