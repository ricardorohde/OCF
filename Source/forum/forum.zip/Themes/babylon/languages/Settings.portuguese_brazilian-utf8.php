<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'O Tema padr&atilde;o do Simple Machines.<br /><br />Os cr&eacute;ditos v&atilde;o para Babylonking e Alienine.';

?>