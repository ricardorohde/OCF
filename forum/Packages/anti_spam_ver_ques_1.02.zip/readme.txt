[b]Anti-Spam Verification Questions[/b]

Version: 1.01 Date 2008-11-24
Compatibility: SMF 1.1.7

[b]Features[/b]

Adds SMF 2.0's anti-spam verification questions to SMF 1.1.7. You can add up to 5 questions which must be answered by the applicant before registration is permitted.

Here are some examples of types of questions that could work. I usually put a hint in the question so that humans can easily figure out what to enter. Spambots on the other hand don't understand human hints. :P

Examples:

[list]
[li]What year is it? (4 digits)[/li]
[li]Are you a robot? (yes or no)[/li]
[li]Please leave this answer blank.[/li]
[/list]

I wrote this modification especially just for all of you 1.1.7 forum operators to see if I can solve your spambot problem once and for all. I've been chuckling as I've been writing my codes, thinking about all the probably weeks of effort that the spambot programmers put into their spammer scripts, thinking that with a few days worth of my own labor I may have possibly wiped them out completely! :D

[b]Configuration[/b]

The settings for this modificaton are located in Admin -> Members -> Registration -> Settings.

[b]Support[/b]

You may get support or submit questions and comments in the modification's [url=http://www.simplemachines.org/community/index.php?topic=276309.0]support topic[/url] at the SMF site.

[b]Donations[/b]

[table][tr][td][url=https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=1400104][img]https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif[/img][/url][/td][td]      [/td][td]If you like my modification packages, please donate to support their continued development. Any amount will be greatly appreciated. Thank you![/td][/tr][/table]

[size=1]Copyright (c) 2008 by Deprecated (at) Earthlink (dot) net. All rights reserved. Redistribution prohibited except at SimpleMachines.org[/size]